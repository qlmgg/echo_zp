<?php
	return array(
		'module'				=>	'Mobile',			//应用别名
		'module_name'			=>	'手机触屏端',				//应用名称
		'appid'					=>	'',
		'version'				=>	'4.2.88',			//版本号
		'is_create_table'		=>	1,					//是否需要创建数据表
		'is_insert_data'		=>	1,					//是否需要添加数据
		'is_exe'				=>	1,					//是否有其它逻辑程序
		'is_delete_data'		=>	1,
		'update_time'			=>	'2018-03-22 15:00',	//当前版本更新时间
		'explain'				=>	'手机访问可自动切换为手机版网站，手机触屏端包含了人才系统的基础功能。'//说明
	);
?>