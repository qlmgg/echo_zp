<?php
class Setup{
    public function run(){
        if(!D('Task')->where(array('title'=>'完善基本资料','t_alias'=>'user_info','utype'=>'2'))->find()){
            $setsqlarr['title'] = 'resume_max';
            $setsqlarr['t_alias'] = 'user_info';
            $setsqlarr['points'] = '20';
            $setsqlarr['once'] = '1';
            $setsqlarr['becount'] = '1';
            $setsqlarr['times'] = '0';
            $setsqlarr['utype'] = '2';
            $setsqlarr['dayly'] = '0';
            $setsqlarr['status'] = '1';
            D('Task')->add($setsqlarr);
        }
        if(!D('Task')->where(array('title'=>'邀请注册','t_alias'=>'invitation_reg','utype'=>'2'))->find()){
            $setsqlarr['title'] = '邀请注册';
            $setsqlarr['t_alias'] = 'invitation_reg';
            $setsqlarr['points'] = '10';
            $setsqlarr['once'] = '0';
            $setsqlarr['becount'] = '0';
            $setsqlarr['times'] = '-1';
            $setsqlarr['utype'] = '2';
            $setsqlarr['dayly'] = '0';
            $setsqlarr['status'] = '1';
            D('Task')->add($setsqlarr);
        }
        if(!D('Task')->where(array('title'=>'推荐注册','t_alias'=>'invitation_reg','utype'=>'1'))->find()){
            $setsqlarr['title'] = '推荐注册';
            $setsqlarr['t_alias'] = 'invitation_reg';
            $setsqlarr['points'] = '10';
            $setsqlarr['once'] = '0';
            $setsqlarr['becount'] = '0';
            $setsqlarr['times'] = '-1';
            $setsqlarr['utype'] = '1';
            $setsqlarr['dayly'] = '0';
            $setsqlarr['status'] = '1';
            D('Task')->add($setsqlarr);
        }
        if(!D('Task')->where(array('title'=>'绑定淘宝账号','t_alias'=>'binding_taobao','utype'=>'2'))->find()){
            $setsqlarr['title'] = '绑定淘宝账号';
            $setsqlarr['t_alias'] = 'user_info';
            $setsqlarr['points'] = '10';
            $setsqlarr['once'] = '1';
            $setsqlarr['becount'] = '1';
            $setsqlarr['times'] = '0';
            $setsqlarr['utype'] = '2';
            $setsqlarr['dayly'] = '0';
            $setsqlarr['status'] = '1';
            D('Task')->add($setsqlarr);
        }
        if(!D('Task')->where(array('title'=>'绑定淘宝账号','t_alias'=>'binding_taobao','utype'=>'1'))->find()){
            $setsqlarr['title'] = '绑定淘宝账号';
            $setsqlarr['t_alias'] = 'user_info';
            $setsqlarr['points'] = '10';
            $setsqlarr['once'] = '1';
            $setsqlarr['becount'] = '1';
            $setsqlarr['times'] = '0';
            $setsqlarr['utype'] = '1';
            $setsqlarr['dayly'] = '0';
            $setsqlarr['status'] = '1';
            D('Task')->add($setsqlarr);
        }
    }
}
?>